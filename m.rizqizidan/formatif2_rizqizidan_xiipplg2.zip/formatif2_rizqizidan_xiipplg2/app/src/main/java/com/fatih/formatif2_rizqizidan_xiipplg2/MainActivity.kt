package com.fatih.formatif2_rizqizidan_xiipplg2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Adapter
import androidx.recyclerview.widget.LinearLayoutManager
import com.fatih.formatif2_rizqizidan_xiipplg2.databinding.ActivityInputBukuBinding
import com.fatih.formatif2_rizqizidan_xiipplg2.databinding.ActivityMainBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private var list = mutableListOf<buku>()
    private lateinit var adapter:buku_adapter
    private val db by lazy { db_perpustakaanSA(this) }
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        this.setRecycle()
        binding.floatingActionButton.setOnClickListener {
            startActivity(
                Intent(this,InputBukuActivity::class.java)
            )
        }


    }
    fun setRecycle(){
        adapter= buku_adapter(list)
        binding.recycleview.adapter = adapter
        binding.recycleview.layoutManager = LinearLayoutManager(this)
        this.getData()
    }
    fun getData(){
        CoroutineScope(Dispatchers.IO). launch {
            list.addAll(db.buku_DAO().tampil_buku())
            withContext(Dispatchers.Main){
                adapter.notifyDataSetChanged()
            }
        }
    }
}
