package com.fatih.formatif2_rizqizidan_xiipplg2

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class buku(
    @PrimaryKey(autoGenerate = true)
    val Id_buku: Int,
    val judul_buku: String,
    val jumlah_buku: Int,
    val pengarang_buku: String,
    val penerbit_buku: String
    )