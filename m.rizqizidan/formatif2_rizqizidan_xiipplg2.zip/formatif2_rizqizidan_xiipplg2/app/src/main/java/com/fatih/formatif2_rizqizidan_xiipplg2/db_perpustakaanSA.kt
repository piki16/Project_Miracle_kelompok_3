package com.fatih.formatif2_rizqizidan_xiipplg2

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities =  [buku::class], version = 1)
abstract class db_perpustakaanSA : RoomDatabase(){
    abstract fun buku_DAO() : buku_DAO

    companion object {


        @Volatile private var instance: db_perpustakaanSA? = null
        private val LOCK = Any()

        operator fun invoke(context: Context) = instance ?: synchronized(LOCK) {
            instance ?: buildDatabase(context).also{
                instance = it
            }

        }

        private fun buildDatabase(context: Context) = Room.databaseBuilder(
            context.applicationContext,
            db_perpustakaanSA::class.java,
            "PerpustakaanSA").fallbackToDestructiveMigration().build()
    }
}