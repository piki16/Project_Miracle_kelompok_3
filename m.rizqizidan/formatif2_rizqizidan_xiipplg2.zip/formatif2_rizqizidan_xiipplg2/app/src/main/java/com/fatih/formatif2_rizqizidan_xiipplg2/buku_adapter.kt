package com.fatih.formatif2_rizqizidan_xiipplg2

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class buku_adapter(val list:List<buku>):
RecyclerView.Adapter<buku_adapter.ViewHolder>(){
    class ViewHolder(view: View):RecyclerView.ViewHolder(view){
        val judulBuku = itemView.findViewById<TextView>(R.id.txtjudul_buku)
        val jumlahBuku = itemView.findViewById<TextView>(R.id.txtjumlah_buku)
        val pengarang = itemView.findViewById<TextView>(R.id.txtpengarang)
        val penerbit = itemView.findViewById<TextView>(R.id.txtpenerbit)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):ViewHolder {
        return ViewHolder(
            LayoutInflater.from(parent.context)
                .inflate(
                    R.layout.adapter_buku,
                    parent,
                    false
                )
        )

    }

    override fun onBindViewHolder(holder:ViewHolder, position: Int) {
        holder.judulBuku.text = list[position].judul_buku
        holder.jumlahBuku.text = list[position].jumlah_buku.toString()
        holder.penerbit.text = list[position].penerbit_buku
        holder.pengarang.text = list[position].pengarang_buku
    }

    override fun getItemCount(): Int {
        return list.size
    }
}