package com.fatih.formatif2_rizqizidan_xiipplg2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.fatih.formatif2_rizqizidan_xiipplg2.databinding.ActivityInputBukuBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class InputBukuActivity : AppCompatActivity() {
    private lateinit var bindInput: ActivityInputBukuBinding
    private val db by lazy { db_perpustakaanSA(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bindInput = ActivityInputBukuBinding.inflate(layoutInflater)
        setContentView(bindInput.root)
        this.inputdataBuku()
    }
    private fun inputdataBuku(){
        bindInput.btnSimpan.setOnClickListener{
            CoroutineScope(Dispatchers.IO).launch{
                db.buku_DAO().simpan_buku()
                    buku(
                        Id_buku = 0,
                        bindInput.etjudulBuku.text.toString(),
                        bindInput.etjumlahBuku.text.toString().toInt(),
                        bindInput.etpengarang.text.toString(),
                        bindInput.etpenerbit.text.toString()


                    )

            }
            startActivity(Intent(this,MainActivity::class.java))
        }
    }
}