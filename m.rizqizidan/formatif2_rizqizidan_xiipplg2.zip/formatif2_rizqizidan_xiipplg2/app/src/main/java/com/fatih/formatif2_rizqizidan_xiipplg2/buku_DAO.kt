package com.fatih.formatif2_rizqizidan_xiipplg2

import androidx.room.*

@Dao
interface buku_DAO {
    @Insert
    fun simpan_buku(vararg brg:buku)
    @Update
    fun ubah_buku(vararg brg:buku)
    @Delete
    fun hapus_buku(vararg brg:buku)
    @Query("Select*from buku")
    fun tampil_buku() : List <buku>
}